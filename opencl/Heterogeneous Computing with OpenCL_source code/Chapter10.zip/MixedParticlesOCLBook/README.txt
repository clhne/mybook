Press A to run the simulation, R to reset. 

Note that the rendering does not match the styling in the screenshots in the book. This is because the sample has been simplified to remove the complexity of the DirectX rendering to make the OpenCL code more visible.