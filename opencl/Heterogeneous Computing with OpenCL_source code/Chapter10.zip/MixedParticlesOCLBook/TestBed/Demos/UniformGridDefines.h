#ifndef D_UNIFORM_GRID_DEFINES_H
#define D_UNIFORM_GRID_DEFINES_H

#define MAX_IDX_PER_GRID 6


#endif
