#include <CL/cl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <fstream>
#include <math.h>

#define SUCCESS 0
#define FAILURE 1

using namespace std;

// OpenCL kernel. Each work item takes care of one element of c
const char *kernelSource =                                               "\n" \
"#ifdef cl_khr_fp64\n" \
"#pragma OPENCL EXTENSION cl_khr_fp64 : enable\n" \
"#endif\n" \
"__kernel void vecAdd(  __global float *a,                      \n" \
"                                     __global float *b,                      \n" \
"                                     __global float *c,                      \n" \
"                                     const unsigned int n)                   \n" \
"{                                                                                        \n" \
"    //Get our global thread ID                                            \n" \
"    int id = get_global_id(0);                                              \n" \
"                                                                                         \n" \
"    //Make sure we do not go out of bounds                      \n" \
"    if (id < n)                                                                       \n" \
"        c[id] = a[id] + b[id];                                                   \n" \
"}                                                                                        \n" \
                                                                                         "\n" ;
 
int main( int argc, char* argv[] )
{
    // Length of vectors
    unsigned int n = 10;
	cl_int	err;
    // Size, in bytes, of each vector
    size_t bytes = n*sizeof(float);

	/*Step1: Getting platforms and choose an available one.*/
	cl_uint numPlatforms;	//the NO. of platforms
	cl_platform_id platform = NULL;	//the chosen platform
	
// Bind to platform
err = clGetPlatformIDs(1, &platform, NULL);
 
	cl_uint				numDevices = 0;
	cl_device_id        *devices;
	err |= clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 0, NULL, &numDevices);	
	if (numDevices == 0)	//no GPU available.
	{
		cout << "No GPU device available." << endl;
		cout << "Choose CPU as default device." << endl;
		err |= clGetDeviceIDs(platform, CL_DEVICE_TYPE_CPU, 0, NULL, &numDevices);	
		devices = (cl_device_id*)malloc(numDevices * sizeof(cl_device_id));
		err |= clGetDeviceIDs(platform, CL_DEVICE_TYPE_CPU, numDevices, devices, NULL);
	}
	else
	{
		devices = (cl_device_id*)malloc(numDevices * sizeof(cl_device_id));
		err |= clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, numDevices, devices, NULL);
	}

	cl_device_svm_capabilities svm;
	clGetDeviceInfo(devices[0], CL_DEVICE_SVM_CAPABILITIES, sizeof(svm), &svm, NULL);
	if (svm&CL_DEVICE_SVM_FINE_GRAIN_SYSTEM)
		printf("CL_DEVICE_SVM_FINE_GRAIN_SYSTEM\n");
	else
		cout << "CL_DEVICE_SVM_FINE_GRAIN_SYSTEM unsupported." << endl;
	if (svm&CL_DEVICE_SVM_FINE_GRAIN_BUFFER)
		printf("CL_DEVICE_SVM_FINE_GRAIN_BUFFER supported\n");
	else
		cout << "CL_DEVICE_SVM_FINE_GRAIN_BUFFER unsupported." << endl;
	if (svm&CL_DEVICE_SVM_COARSE_GRAIN_BUFFER)
		printf("CL_DEVICE_SVM_COARSE_GRAIN_BUFFER supported\n");
	else
		cout << "CL_DEVICE_SVM_COARSE_GRAIN_BUFFER unsupported." << endl;

// Create a context
cl_context_properties cps[3] =
{
CL_CONTEXT_PLATFORM,
(cl_context_properties)platform,
0
};
//context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);
cl_context context = clCreateContextFromType(cps, CL_DEVICE_TYPE_GPU, NULL, NULL, &err);

	if (err != CL_SUCCESS)
	{
		cout << "clCreateContextFromType!" << endl;
		return FAILURE;
	}
	
// Create a command queue
cl_command_queue queue = clCreateCommandQueueWithProperties(context, devices[0], 0, &err);
	if (err != CL_SUCCESS)
	{
		cout << "clCreateCommandQueueWithProperties!" << endl;
		return FAILURE;
	}
	
// Create the compute program from the source buffer
cl_program program = clCreateProgramWithSource(context, 1,
                            (const char **) & kernelSource, NULL, &err);
	if (err != CL_SUCCESS)
	{
		cout << "clCreateProgramWithSource!" << endl;
		return FAILURE;
	}
	
// Build the program executable
const char options[] = "-cl-std=CL2.0";
clBuildProgram(program, 1, devices, options,NULL,NULL);

	if (err != CL_SUCCESS)
	{
		cout << "clBuildProgram!" << endl;
		return FAILURE;
	}
	
// Create the compute kernel in the program we wish to run
cl_kernel kernel = clCreateKernel(program, "vecAdd", &err);
	if (err != CL_SUCCESS)
	{
		cout << "clCreateKernel!" << endl;
		return FAILURE;
	}
	
float* h_a = (float*)clSVMAlloc(context, CL_MEM_READ_ONLY, bytes, 0);
float* h_b = (float*)clSVMAlloc(context, CL_MEM_READ_ONLY, bytes, 0);
float* h_c = (float*)clSVMAlloc(context, CL_MEM_WRITE_ONLY, bytes, 0);
	
clEnqueueSVMMap(queue, CL_TRUE, CL_MAP_WRITE_INVALIDATE_REGION, h_a, bytes, 0, NULL, NULL);
clEnqueueSVMMap(queue, CL_TRUE, CL_MAP_WRITE_INVALIDATE_REGION, h_b, bytes, 0, NULL, NULL);
clEnqueueSVMMap(queue, CL_TRUE, CL_MAP_WRITE_INVALIDATE_REGION, h_c, bytes, 0, NULL, NULL);
	if (err != CL_SUCCESS)
	{
		cout << "clEnqueueSVMMap!" << endl;
		return FAILURE;
	}
	
// Initialize vectors on host
    int i;
    for( i = 0; i < n; i++ )
    {
        h_a[i] = i;
        h_b[i] = i;
        h_c[i] = 0;
    }
 
clEnqueueSVMUnmap(queue, h_a, 0, NULL, NULL);
clEnqueueSVMUnmap(queue, h_b, 0, NULL, NULL);
clEnqueueSVMUnmap(queue, h_c, 0, NULL, NULL);
	if (err != CL_SUCCESS)
	{
		cout << "clEnqueueSVMUnmap!" << endl;
		return FAILURE;
	}
	
// Set the arguments to our compute kernel
err = clSetKernelArgSVMPointer(kernel, 0, (float*)h_a);
err |= clSetKernelArgSVMPointer(kernel, 1, (float*)h_b);
err |= clSetKernelArgSVMPointer(kernel, 2, (float*)h_c);
	if (err != CL_SUCCESS)
	{
		cout << "clSetKernelArgSVMPointer!" << endl;
		return FAILURE;
	}
	
err |= clSetKernelArg(kernel, 3, sizeof(unsigned int), &n);
	if (err != CL_SUCCESS)
	{
		cout << "clSetKernelArg!" << endl;
		return FAILURE;
	}
	
// Execute the kernel over the entire range of the data set
size_t globalSize = {n};
err = clEnqueueNDRangeKernel(queue, kernel, 1, NULL, &globalSize, NULL,
                                                              0, NULL, NULL);
// Wait for the command queue to get serviced before reading back results
clFinish(queue);

	if (err != CL_SUCCESS)
	{
		cout << "clEnqueueNDRangeKernel!" << endl;
		return FAILURE;
	}
	
clEnqueueSVMMap(queue, CL_TRUE, CL_MAP_READ, h_c, bytes, 0, NULL, NULL);
 
//Sum up vector c and print result divided by n, this should equal 1 within error
    float sum = 0;
    for(i=0; i<n; i++)
        sum += h_c[i];
    printf("final result: %f\n", sum/n);
 
clSVMFree(context, h_a);
clSVMFree(context, h_b);
clSVMFree(context, h_c);
clEnqueueSVMUnmap(queue, h_c, 0, NULL, NULL);
    clReleaseProgram(program);
    clReleaseKernel(kernel);
    clReleaseCommandQueue(queue);
    clReleaseContext(context);
 
return 0;
}